#include <gtk/gtk.h>


void
on_button1_clicked (GtkWidget *button, gpointer user_data);
void
on_button2_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button6_clicked (GtkWidget *objet_graphique, gpointer user_data);


void
on_button8_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button11_clicked (GtkWidget  *objet_graphique, gpointer user_data);


/*
void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
*/
void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);





void
on_button30_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button39_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
/*
void
on_button41_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button40_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_button_seance_di_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_dispo_di_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_regime_di_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnx_di_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_diet_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficher_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_regime_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_liste1_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_menu_diet_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter_disp_diet_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficher_disp_diet_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour2_disp_diet_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficherseance_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter3_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_ajoutseance_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimer_diet_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour5_diet_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficher_dietseance_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_dietseance_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_dietseance_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_message_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ajouter_message_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_message_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_menu_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_msg_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider_msg_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_menu_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Contact_coach_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_diet3_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_afficher_profile_clicked     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_profil_di_clicked            (GtkWidget       *button,
                                        gpointer         user_data);
