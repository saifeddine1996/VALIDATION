#include <gtk/gtk.h>
typedef struct
{
char cin[20];
char nom[20];
char prenom[30];
char date_naissance[30];
char adresse[10];
}Personne;
typedef struct
{
int jour;
int mois;
int annee;
}date1;
typedef struct
{
char type[50];
}seance1;
typedef struct
{
int jour;
int mois;
int annee;
int numero;
}date2;

typedef struct
{
char name_seance[50];
char objectif_seance[50];
}seance2;

typedef struct
{
char mess[50];
}envoi;

typedef struct
{
char champ1[50];
char champ2[50];
char champ3[50];
char champ4[50];
char champ5[50];
}pro;


//void afficher_profile(pro j);
void ajout_envoi(envoi m);
void ajout_seance2_di(seance2 b, date2 a);
void ajout_seance_di(seance1 y, date1 z);
void ajouter_regime_di(Personne p);//interface loula fiha 5 text entry
void  afficher_diet_di(GtkWidget *liste);
void afficher_seance_di (GtkWidget *liste );
void afficher_seance2_di (GtkWidget *liste );
//int verif_dispo_di (seance1 y,date1 z);
void supprimer_dispo_di(int spinbutton8_diet);
void modifier_seance_di (seance2 b, date2 a);

