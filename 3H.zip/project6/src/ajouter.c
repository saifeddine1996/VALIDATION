#include <stdio.h>
#include <stdlib>
#include <string.h>
#include "ajouter.h"
void ajouter (char Username[],char Password,int role)
{f=foper("users.txt""a+");
if (f!=NULL)
{
printf("saisir les données");
fflush(stdin);
gets(Username);
fflush(stdin);
gets(Password);
scanf("%d",&role);
fprintf(f,"%s %s %d\n",Username,Password,role);
}
fclose(f);
}

