#include "verifier.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
int verifier (char Username[], char Password[])
{
FILE*f;
int role12=0;
char Username1[30],Password1[30];
f=fopen("users.txt","r");
if (f!=NULL)
{while (fscanf(f,"%s %s %d \n",Username1,Password1,&role12)!=EOF)
{
if(strcmp(Username1,Username)==0 && strcmp(Password1,Password)==0)
{
return role12;
}}
return 0;
}
fclose(f);
}
