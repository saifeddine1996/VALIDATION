#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ajout.h"
#include <gtk/gtk.h>

///////////////////ajout seance/////////////////////////////

void ajout_seance (seance s, date d)
{
FILE *f;
f=fopen("seances.txt","a+");
fprintf(f," %d %s %s %s %d %d %d %s\n",d.numero,s.nom,s.typesc,s.categorie,d.jour,d.mois,d.annee,s.heure);	
fclose(f);
}
///////////////////afficher seance/////////////////////////////
void afficher_seance (GtkWidget *liste ) 
{ 
enum { 
       
       JOUR,
       MOIS, 
       ANNEE, 	
       HEURE,
       CATEGORIE,
       NOM,
       TYPESC,
       NUMERO,
       COLUMNS
       
      };
char nom[30],typesc[30],categorie[30],heure[30],jour[30],mois[30],annee[30],numero[30];
	GtkTreeIter iter;
	GtkListStore *store;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	store=NULL;
FILE *f;
		
	        if (store==NULL)
{

 renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("numero", renderer,"text",NUMERO,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("typesc", renderer,"text",TYPESC,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("categorie",         renderer,"text",CATEGORIE,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour", renderer,"text",JOUR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("heure", renderer,"text",HEURE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
  		store=gtk_list_store_new				(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	        
}
f=fopen("seances.txt","r");
if(f!=NULL)
{

while(fscanf(f,"%s %s %s %s %s %s %s %s\n",numero,nom,typesc,categorie,jour,mois,annee,heure)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NUMERO,numero,NOM,nom,TYPESC,typesc,CATEGORIE,categorie,JOUR,jour,MOIS,mois,ANNEE,annee,HEURE,heure,-1);
}

gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
}
fclose(f);
}
///////////////////verif ajout seance/////////////////////////////
int verif (seance s,date d)
{
FILE*f;
int x=0;

char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
int jour1;
int mois1;
int annee1;
int numero1;
f=fopen("seances.txt","r");
if (f!=NULL)
{while (fscanf(f,"%d %s %s %s %d %d %d %s\n",&numero1,combobox13,combobox14,combobox12,&jour1,&mois1,&annee1,combobox11)!=EOF)
{
if(  (numero1==d.numero))
return (1);
}

}
fclose(f);
return (0);
}

///////////////////ajout disponibilité/////////////////////////////

void ajout_disp (day da, jour j)
{
FILE *f;
f=fopen("disp.txt","a+");
fprintf(f,"%d %s %d %d %d %s \n",da.num,j.jour_disp,da.jour3,da.mois3,da.annee3,j.pres);	
fclose(f);
}



///////////////////afficher disponibilité/////////////////////////////

void afficher_disponibilite (GtkWidget *liste ) 
{ 
enum { 
       
       NUM,
       JOUR_DISP, 
       JOUR3, 	
       MOIS3,
       ANNEE3,
       PRES,
       COLUMNS
       
      };
char num[30],jour_disp[30],jour3[30],mois3[30],annee3[30],pres[30];
	GtkTreeIter iter;
	GtkListStore *store;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	store=NULL;
FILE *f;
		
	        if (store==NULL)
{
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num",              renderer,"text",NUM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour_disp", renderer,"text",JOUR_DISP,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour3", renderer,"text",JOUR3,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois3",         renderer,"text",MOIS3,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee3", renderer,"text",ANNEE3,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("pres", renderer,"text",PRES,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
                
  		store=gtk_list_store_new				(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	        
}
f=fopen("disp.txt","r");
if(f!=NULL)
{

while(fscanf(f,"%s %s %s %s %s %s \n",num,jour_disp,jour3,mois3,annee3,pres)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NUM,num,JOUR_DISP,jour_disp,JOUR3,jour3,MOIS3,mois3,ANNEE3,annee3,PRES,pres,-1);
}

gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
}
fclose(f);
}



///////////////////supprimer seance/////////////////////////////


void supprimer(int choix)
{
FILE*f;
FILE*f1;

seance s;
date d;

char nom[50],typesc[50],categorie[50],heure[50];
int jour,mois,annee,numero ;



f=fopen("seances.txt","r");
f1=fopen("fichier.txt","a+");

while(fscanf(f,"%d %s %s %s %d %d %d %s",&d.numero,s.nom,s.typesc,s.categorie,&d.jour,&d.mois,&d.annee,s.heure)!=EOF)
{
if(d.numero!=choix)

fprintf(f1,"%d %s %s %s %d %d %d %s\n",d.numero,s.nom,s.typesc,s.categorie,d.jour,d.mois,d.annee,s.heure);
}
fclose(f);
fclose(f1);
rename("fichier.txt","seances.txt");

}


///////////////////verif ajout disp/////////////////////////////
int verif_disp (day da,jour j)
{
FILE*f;
int x=0;

char jour_disp33[30];
char pres33[30];

int jour33;
int mois33;
int annee33;
int num33;
f=fopen("disp.txt","r");
if (f!=NULL)
{while (fscanf(f,"%d %s %d %d %d %s\n",&num33,jour_disp33,&jour33,&mois33,&annee33,pres33)!=EOF)
{
if(  (num33==da.num))
return (1);
}

}
fclose(f);
return (0);
}





///////////////////supprimer disp/////////////////////////////


void supprimer_disp(int choix2)
{
FILE*f;
FILE*f1;

day da;
jour j;

char jour_disp[50],pres[50];
int num,jour3,annee3,mois3 ;



f=fopen("disp.txt","r");
f1=fopen("fichier1.txt","a+");

while(fscanf(f,"%d %s %d %d %d %s ",&da.num,j.jour_disp,&da.jour3,&da.mois3,&da.annee3,j.pres)!=EOF)
{
if(da.num!=choix2)

fprintf(f1,"%d %s %d %d %d %s\n",da.num,j.jour_disp,da.jour3,da.mois3,da.annee3,j.pres);
}
fclose(f);
fclose(f1);
rename("fichier1.txt","disp.txt");
}





///////////////////modifier seance/////////////////////////////


void modifier_seance (seance s, date d)
{
char var2[50],var3[50],var4[50],var8[50];
int var1,var5,var6,var7 ; 

FILE* f;
FILE* m;
f=fopen("seances.txt","r");
m=fopen("modif.txt","a+");
while(fscanf(f,"%d %s %s %s %d %d %d %s",&var1,var2,var3,var4,&var5,&var6,&var7,var8)!=EOF)
{
if (var1 == d.numero)
fprintf(m,"%d %s %s %s %d %d %d %s \n",d.numero,s.nom,s.typesc,s.categorie,d.jour,d.mois,d.annee,s.heure);
else 
fprintf(m,"%d %s %s %s %d %d %d %s\n",var1,var2,var3,var4,var5,var6,var7,var8);
} 
fclose(f);
fclose(m);
rename("modif.txt","seances.txt");
}


/*

///////////////////verif modif seance/////////////////////////////
int verif_modif_seance (seance s,date d)
{
FILE*f;
int x=0;

char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
int jour1;
int mois1;
int annee1;
int numero1;
f=fopen("/home/akrem123/Projects/project2/src/seances.txt","r");
if (f!=NULL)
{while (fscanf(f,"%d %s %s %s %d %d %d %s\n",&numero1,combobox13,combobox14,combobox12,&jour1,&mois1,&annee1,combobox11)!=EOF)
{
if(  (numero1!=d.numero))
return (1);
}

}
fclose(f);
return (0);
}
*/





///////////////////modifier disponibilité/////////////////////////////


void modifier_disponibilite (jour j, day da)
{
char var2[50],var6[50];
int var1,var3,var4,var5; 

FILE* f;
FILE* m1;
f=fopen("disp.txt","r");
m1=fopen("modif1.txt","a+");
while(fscanf(f,"%d %s %d %d %d %s",&var1,var2,&var3,&var4,&var5,var6)!=EOF)
{
if (var1 == da.num)
fprintf(m1,"%d %s %d %d %d %s\n",da.num,j.jour_disp,da.jour3,da.mois3,da.annee3,j.pres);
else 
fprintf(m1,"%d %s %d %d %d %s\n",var1,var2,var3,var4,var5,var6);
} 
fclose(f);
fclose(m1);
rename("modif1.txt","disp.txt");
}
/*

////////////////ajout profil/////////////////

void ajouter_profil_coach (p)
{
FILE*f;
f=fopen("profil.txt" ,"w");

if(f!=NULL)
{

fprintf(f,"%s,%s,%s,%s,%s\n" , p.Nom , p.Prenom , p.Cin , p.Age , p.Numero);


fclose(f);
}
}
*/




/////////fct ajouter message//////////
void ajouter_message(message me)
{
FILE *f;
f=fopen("message_dietitien.txt","a+");
fprintf(f,"%s \n",me.msg1);
fclose(f);
}

