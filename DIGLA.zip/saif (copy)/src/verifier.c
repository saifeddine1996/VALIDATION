#include<stdio.h>
#include <string.h>
#include"verifier.h"
#include<stdlib.h>
int verifier (char login[20], char password[])
{
FILE*f;
char login1[20];char password1[20];
int role=1;
f=fopen("user.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %d \n",login1,password1,&role)!=EOF)
{
if((strcmp(login,login1)==0) && (strcmp(password,password1) ==0))
{
return(role);
}
}
return 0 ;
}
fclose(f);
}
