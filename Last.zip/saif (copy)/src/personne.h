#include <gtk/gtk.h>
typedef struct
{
char cin[20];
char nom[20];
char prenom[30];
char date_naissance[30];
char adresse[10];
}Personne;
typedef struct
{
int jour;
int mois;
int annee;
int num;
}date;
typedef struct
{
char type[50];
}seance;
typedef struct
{
int jour;
int mois;
int annee;
int numero;
}date2;

typedef struct
{
char name_seance[50];
char objectif_seance[50];
}seance2;
typedef struct
{
char mess[50];
}envoi;

void supprimer2(int sup2);
void ajout_envoi(envoi m);
void ajout_seance2(seance2 b, date2 a);
void ajout_seance(seance s, date d);
void ajouter_personne(Personne p);
void afficher_personne(GtkWidget *liste);
void afficher_seance (GtkWidget *liste );
void afficher_seance2 (GtkWidget *liste );
int verif (seance s,date d);
void supprimer(int sup);
void modifier_seance (seance2 b, date2 a);
