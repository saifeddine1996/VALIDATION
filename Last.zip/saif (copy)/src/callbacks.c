#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "verifier.c"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
char login[20];
char password[20];
int x;
GtkWidget *nom;
GtkWidget *pass;
GtkWidget *fenetre_login_diet;
GtkWidget *MSG;
GtkWidget *DIET;
//GtkWidget *current;
nom=lookup_widget(objet,"entry1");
pass=lookup_widget(objet,"entry2");
MSG=lookup_widget(objet,"MSG");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(pass)));
x= verifier(login,password);
if(x==3)
{DIET = create_DIET ();
fenetre_login_diet=lookup_widget(objet,"fenetre_login_diet");
gtk_widget_show (DIET);
gtk_widget_hide (fenetre_login_diet);
}else
gtk_label_set_text(GTK_LABEL(MSG),"TRY AGAIN");
}

void
on_back_enter                          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_login_diet;
fenetre_login_diet =create_fenetre_login_diet();
//DIET = create_DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy (DIET);
fenetre_login_diet=lookup_widget(objet,"fenetre_login_diet");
gtk_widget_show (fenetre_login_diet);
}


void
on_next_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_ajout_regime;
//DIET = create_DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy (DIET);
fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");
fenetre_ajout_regime=create_fenetre_ajout_regime();
gtk_widget_show(fenetre_ajout_regime);


}
void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

Personne p;

GtkWidget *input1, *input2,*input3,*input4,*input5;
GtkWidget *fenetre_ajout_regime;

fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");

input1=lookup_widget(objet,"type_diet");
input2=lookup_widget(objet,"date_debut_diet");
input3=lookup_widget(objet,"date_fin_diet");
input4=lookup_widget(objet,"date_diet");
input5=lookup_widget(objet,"Lieux_diet");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));



ajouter_personne(p);


}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_ajout_regime;
GtkWidget *fenetre_afficher_regime;
GtkWidget *treeview1;

fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");


gtk_widget_destroy(fenetre_ajout_regime);
fenetre_afficher_regime=lookup_widget(objet,"fenetre_afficher_regime");
fenetre_afficher_regime=create_fenetre_afficher_regime();

gtk_widget_show(fenetre_afficher_regime);
      

treeview1=lookup_widget(fenetre_afficher_regime,"treeview1");

afficher_personne(treeview1); 



}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget *fenetre_ajout_regime, *fenetre_afficher_regime;

fenetre_afficher_regime=lookup_widget(objet,"fenetre_afficher_regime");


gtk_widget_destroy(fenetre_afficher_regime);
fenetre_ajout_regime=create_fenetre_ajout_regime();
gtk_widget_show(fenetre_ajout_regime);


}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}








void
on_dispo_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter_dispo;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
fenetre_ajouter_dispo=create_fenetre_ajouter_dispo();
gtk_widget_show(fenetre_ajouter_dispo);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter_dispo;
GtkWidget *fenetre_afficher_dispo;
GtkWidget *treeview2;
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
gtk_widget_destroy(fenetre_ajouter_dispo);
fenetre_afficher_dispo=lookup_widget(objet,"fenetre_afficher_dispo");
fenetre_afficher_dispo=create_fenetre_afficher_dispo();
gtk_widget_show(fenetre_afficher_dispo);
treeview2=lookup_widget(fenetre_afficher_dispo,"treeview2");

afficher_seance(treeview2); 

}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
int x;
int jour10;
int mois10;
int annee10;
char combobox10[50];
seance s;
date d;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *combobox1;
GtkWidget *message;
GtkWidget *num;

num=lookup_widget(objet,"spin_delete_1");
jour=lookup_widget(objet,"spinbutton1");
mois=lookup_widget(objet,"spinbutton2");
annee=lookup_widget(objet,"spinbutton3");
combobox1=lookup_widget(objet,"combobox1");
message=lookup_widget(objet,"MESSAE_DIET");

d.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
x=verif(s,d);

if(x==0)
{
ajout_seance(s,d);
gtk_label_set_text(GTK_LABEL(message),"BIEN AJOUTER");
}else
gtk_label_set_text(GTK_LABEL(message),"planning existant");
}

void
on_button4_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher_dispo;
GtkWidget *fenetre_ajouter_dispo;
//GtkWidget *treeview2;
fenetre_afficher_dispo=lookup_widget(objet,"fenetre_afficher_dispo");
gtk_widget_destroy(fenetre_afficher_dispo);
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
fenetre_ajouter_dispo=create_fenetre_ajouter_dispo();
//treeview2=lookup_widget(fenetre_afficher_dispo,"treeview2");
gtk_widget_show(fenetre_ajouter_dispo);
//treeview2=lookup_widget(fenetre_afficher_dispo,"treeview2");
//afficher_seance(treeview2); 
}


void
on_back_dietecien3_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter_dispo, *DIET;
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
gtk_widget_destroy(fenetre_ajouter_dispo);
DIET=create_DIET();
gtk_widget_show(DIET);
}
void
on_add_seance_diet_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_ajouter;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
diet_seance_ajouter=create_diet_seance_ajouter();
gtk_widget_show(diet_seance_ajouter);
}


void
on_ajouter3_diet_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
//int x;
/*int jour11;
int mois12;
int annee11;
char nom_seance_diet[50];
char object_diet[50];*/
seance2 b;
date2 a;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *seance_diet;
GtkWidget *objectif_diet;
GtkWidget *numero;

//GtkWidget *erreur;
jour=lookup_widget(objet,"spinbutton4_diet");
mois=lookup_widget(objet,"spinbutton5_diet");
annee=lookup_widget(objet,"spinbutton6_diet");
seance_diet=lookup_widget(objet,"entry3_diet");
objectif_diet=lookup_widget(objet,"entry4_diet");
numero=lookup_widget(objet,"spinbutton_numero");

a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(b.name_seance,gtk_entry_get_text(GTK_ENTRY(seance_diet)));
strcpy(b.objectif_seance,gtk_entry_get_text(GTK_ENTRY(objectif_diet)));
a.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));

ajout_seance2(b,a);
}

void
on_retour5_diet_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
 
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_ajouter;
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
gtk_widget_destroy(diet_affich_seance);
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
diet_seance_ajouter=create_diet_seance_ajouter();
gtk_widget_show(diet_seance_ajouter);
}


void
on_afficher3_diet_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_ajouter;
GtkWidget *treeview3;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);
treeview3=lookup_widget(diet_affich_seance,"treeview3");
afficher_seance2(treeview3); 
}

void
on_supprimer_diet_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *sup;
//GtkWidget *diet_affich_seance;
//diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
sup=lookup_widget(objet,"sup");
sup=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (sup));
supprimer(sup);


}


void
on_modifier_diet_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_modifier;
GtkWidget *diet_affich_seance;
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
gtk_widget_destroy(diet_affich_seance);
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
diet_seance_modifier=create_diet_seance_modifier();
gtk_widget_show(diet_seance_modifier);

}


void
on_button6_valider_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*seance2 b;
date2 a;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *seance_diet;
GtkWidget *objectif_diet;
GtkWidget *numero;

//GtkWidget *erreur;
jour=lookup_widget(objet,"spinbutton4_diet");
mois=lookup_widget(objet,"spinbutton5_diet");
annee=lookup_widget(objet,"spinbutton6_diet");
seance_diet=lookup_widget(objet,"entry3_diet");
objectif_diet=lookup_widget(objet,"entry4_diet");
numero=lookup_widget(objet,"spinbutton_numero");

a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(b.name_seance,gtk_entry_get_text(GTK_ENTRY(seance_diet)));
strcpy(b.objectif_seance,gtk_entry_get_text(GTK_ENTRY(objectif_diet)));
a.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));

modifier_seance (b,a);
*/
}


void
on_button7_return_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *diet_seance_modifier;
GtkWidget *diet_seance_ajouter;
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
gtk_widget_destroy(diet_seance_modifier);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);*/

}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
seance2 b;
date2 a;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *seance_diet;
GtkWidget *objectif_diet;
GtkWidget *numero;

//GtkWidget *erreur;
jour=lookup_widget(objet,"spinbutton4_diet");
mois=lookup_widget(objet,"spinbutton5_diet");
annee=lookup_widget(objet,"spinbutton6_diet");
seance_diet=lookup_widget(objet,"entry3_diet");
objectif_diet=lookup_widget(objet,"entry4_diet");
numero=lookup_widget(objet,"spinbutton_numero");

a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(b.name_seance,gtk_entry_get_text(GTK_ENTRY(seance_diet)));
strcpy(b.objectif_seance,gtk_entry_get_text(GTK_ENTRY(objectif_diet)));
a.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));

modifier_seance (b,a);
}


void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_modifier;
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
gtk_widget_destroy(diet_seance_modifier);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);

/*
GtkWidget *diet_seance_modifier;
GtkWidget *diet_seance_ajouter;
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
gtk_widget_destroy(diet_seance_modifier);

diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);*/
}


void
on_profile_diet_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*
GtkWidget *fentre_profile_diet;
GtkWidget *DIET;

fentre_profile_diet =create_fentre_profile_diet();
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy (DIET);
fentre_profile_diet=lookup_widget(objet,"fentre_profile_diet");
gtk_widget_show (fentre_profile_diet);*/

}


void
on_bouton_ok_profile_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_button_retour_ajoutseance_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_ajouter;
GtkWidget *DIET;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);

}


void
on_button_retour_regime_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
//fenetre_ajout_regime
//fenetre_afficher_regime

GtkWidget *fenetre_ajout_regime;
GtkWidget *DIET;
fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");
gtk_widget_destroy(fenetre_ajout_regime);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);








}


void
on_back_DIET_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_login_diet;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
DIET=lookup_widget(objet,"fenetre_login_diet");
fenetre_login_diet=create_fenetre_login_diet();
gtk_widget_show(fenetre_login_diet);

}


void
on_Contact_coach_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_contact_coach;


DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
//////////////
fenetre_contact_coach=lookup_widget(objet,"fenetre_contact_coach");
fenetre_contact_coach=create_fenetre_contact_coach();
gtk_widget_show(fenetre_contact_coach);

}

////////////////////////////////////////////////////////////
void
on_button_afficher_msg_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
envoi m;
char ma[30];
GtkWidget *output;
FILE *f;
f=fopen("message_coach.txt","a+");
if (f!=NULL)
{while(fscanf(f,"%s\n",m.mess)!=EOF)
{
output=lookup_widget(objet,"affich_msg");
gtk_label_set_text(GTK_LABEL(output),m.mess);
}
fclose(f);
}
}


void
on_valider_msg_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
envoi m;
GtkWidget *input1;
input1=lookup_widget(objet,"entry_message");

strcpy(m.mess,gtk_entry_get_text(GTK_ENTRY(input1)));
ajout_envoi(m);
}


void
on_button_retour_menu_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *DIET;
GtkWidget *fenetre_contact_coach;


fenetre_contact_coach=lookup_widget(objet,"fenetre_contact_coach");
gtk_widget_destroy(fenetre_contact_coach);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);

}


void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_supp_diet_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sup2;
sup2=lookup_widget(objet,"sup2");
sup2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (sup2));
supprimer(sup2);
}

