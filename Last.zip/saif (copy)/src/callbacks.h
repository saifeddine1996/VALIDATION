#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back_enter                          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_next_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_dispo_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget        *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back_dietecien3_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_add_seance_diet_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter3_diet_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retour5_diet_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher3_diet_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_diet_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_modifier_diet_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button6_valider_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button7_return_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_profile_diet_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_bouton_ok_profile_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_ajoutseance_clicked   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_regime_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back_DIET_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Contact_coach_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_afficher_msg_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider_msg_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_menu_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_diet_clicked            (GtkWidget       *button,
                                        gpointer         user_data);
