#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdio.h>
#include <string.h>
#include "personne.h"
#include <gtk/gtk.h>
void ajout_seance (seance s, date d)
{
FILE *f;
f=fopen("seances.txt","a+");
fprintf(f,"%d %d %d %s %d\n",d.jour,d.mois,d.annee,s.type,d.num);	
fclose(f);
}
//2éme fonction affich
void ajout_seance2 (seance2 b, date2 a)
{
FILE *f;
f=fopen("seancesEntrainement.txt","a+");
fprintf(f,"%d %d %d %d %s %s\n",a.numero,a.jour,a.mois,a.annee,b.name_seance,b.objectif_seance);	
fclose(f);
}
void afficher_seance (GtkWidget *liste ) 
{ 
enum { 
       
       JOUR,
       MOIS, 
       ANNEE, 	
       TYPE,
	NUM,
       COLUMNS
       
      };
char type[30],jour[30],mois[30],num[30],annee[30];
	GtkTreeIter iter;
	GtkListStore *store;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	store=NULL;
FILE *f;
		
	        if (store==NULL)
{
    	        /*renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("typesc", renderer,"text",TYPESC,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("categorie",         renderer,"text",CATEGORIE,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);*/
		
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour", renderer,"text",JOUR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("type", renderer,"text",TYPE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num", renderer,"text",NUM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
  		store=gtk_list_store_new				(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	        
}
f=fopen("seances.txt","r");
if(f!=NULL)
{

while(fscanf(f,"%s %s %s %s\n",jour,mois,annee,type,num)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,JOUR,jour,MOIS,mois,ANNEE,annee,TYPE,type,NUM,num,-1);
}

gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
}
fclose(f);
}
//fonction verifier 

int verif (seance s,date d)
{
FILE*f;
int x=0;

char type10[30];
int jour10;
int mois10;
int annee10;
f=fopen("seances.txt","r");
if (f!=NULL)
{while (fscanf(f,"%d %d %d %s\n",&jour10,&mois10,&annee10,type10)!=EOF)
{
if((jour10==d.jour) && (mois10==d.mois) && (annee10==d.annee) && strcmp(type10,s.type)==0)
return (1);
}

}
fclose(f);
return (0);
}
//affichage seance 2
void afficher_seance2 (GtkWidget *liste ) 
{ 
enum { 
       NUMERO,
       JOUR,
       MOIS, 
       ANNEE, 	
       NAME,
       OBJECT,
       COLUMNS
       
      };
char numero[30],name[30],jour[30],mois[30],annee[30],object[30];
	GtkTreeIter iter;
	GtkListStore *store;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	store=NULL;
FILE *f;
		
	        if (store==NULL)
{
    	        /*renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

    	        renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("typesc", renderer,"text",TYPESC,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                */		

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("numero", renderer,"text",NUMERO,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour", renderer,"text",JOUR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE,NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("name", renderer,"text",NAME,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("object", renderer,"text",OBJECT,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
			
  		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	        
}
f=fopen("seancesEntrainement.txt","r");
if(f!=NULL)
{

while(fscanf(f,"%s %s %s %s %s %s\n",numero,jour,mois,annee,name,object)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NUMERO,numero,JOUR,jour,MOIS,mois,ANNEE,annee,NAME,name,OBJECT,object,-1);
}

gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
}
fclose(f);
}


//////////////////////////////////////////////////////////////////////////////////////////
enum   
{       
        CIN,
        NOM,
	PRENOM,
        DATE,
        ADRESSE,
        COLUMNS
};

//Ajouter une personne

void ajouter_personne(Personne p)
{

 FILE *f;
  f=fopen("utilisateur.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.adresse);
  fclose(f);

}

}


//Afficher une personne


void afficher_personne(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char nom [30];
	char prenom [30];
	char date [30];
	char adresse [30];
        char cin[30];
        store=NULL;

       FILE *f;
	
	//store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  TYPE FORMATION", renderer, "text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" DATE DÉBUT", renderer, "text",NOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  DATE FIN", renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  DATE", renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Lieux", renderer, "text",ADRESSE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("utilisateur.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("utilisateur.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s \n",cin,nom,prenom,date,adresse)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, CIN, cin, NOM, nom, PRENOM, prenom,DATE,date,ADRESSE,adresse, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
//////////////////////////////// supprimer /////////////////////////////////////////////
void supprimer(int sup)
{
FILE*f;
FILE*f1;

seance2 b;
date2 a;

int jour;
int mois;
int annee;
int numero;
char objectif_seance[30];
char name_seance[30];


f=fopen("seancesEntrainement.txt","r");
f1=fopen("newseances.txt","a+");

while(fscanf(f,"%d %d %d %d %s %s\n",&a.numero,&a.jour,&a.mois,&a.annee,b.objectif_seance,b.name_seance)!=EOF)  
{
if(a.numero!=sup)
fprintf(f1,"%d %d %d %d %s %s\n",a.numero,a.jour,a.mois,a.annee,b.objectif_seance,b.name_seance);
}

fclose(f);
fclose(f1);
rename("newseances.txt","seancesEntrainement.txt");
}
/////////////////////////////////////////// MODIFIER ////////////////////////////////////////////////
void modifier_seance (seance2 b, date2 a)
{
char name_seance10[30];
char objectif_seance10[30];
int jour10,mois10,annee10,numero10; 

FILE* f;
FILE* f2;
f=fopen("seancesEntrainement.txt","r");
f2=fopen("modif.txt","a+");
while(fscanf(f,"%d %d %d %d %s %s\n",&numero10,&jour10,&mois10,&annee10,name_seance10,objectif_seance10)!=EOF)
{
if (numero10==a.numero)
fprintf(f2,"%d %d %d %d %s %s\n",a.numero,a.jour,a.mois,a.annee,b.name_seance,b.objectif_seance);
else 
fprintf(f2,"%d %d %d %d %s %s\n",numero10,jour10,mois10,annee10,name_seance10,objectif_seance10);
} 
fclose(f);
fclose(f2);
rename("modif.txt","seancesEntrainement.txt");
}
//////////////////////////////////////////// fonction envoi message /////////////////////////////////////
void ajout_envoi(envoi m)
{
FILE *f;
f=fopen("message_coach.txt","a+");
fprintf(f,"%s\n",m.mess);
fclose(f);
}///////////////////void supprimer 2 eme interface ///////////////////////
void supprimer2(int sup2)
{
FILE*f;
FILE*f1;

seance s;
date d;

int jour;
int mois;
int annee;
int num;
char type[30];


f=fopen("seances.txt","r");
f1=fopen("temp.txt","a+");

while(fscanf(f,"%d %d %d %s %d\n",&d.jour,&d.mois,&d.annee,s.type,&d.num)!=EOF);
{
if(d.num!=sup2)
fprintf(f1,"%d %d %d %s %d\n",d.jour,d.mois,d.annee,s.type,d.num);
}

fclose(f);
fclose(f1);
rename("tempo.txt","seances.txt");
}
